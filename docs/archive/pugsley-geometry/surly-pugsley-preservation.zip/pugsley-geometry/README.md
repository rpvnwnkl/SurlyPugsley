# Preserved Surly Pugsley references

Captured September 26, 2026 UTC (September 25 in New York).

## Open the archive

- [2016 legacy Pugsley: styled offline page](offline/2016.html)
- [Pugsley Gen. 2: styled offline page](offline/gen2.html)
- [2016 frame sheet](2016-frame-sheet.pdf)
- [Gen. 2 frame sheet](gen2-frame-sheet.pdf)

Open `offline/index.html` in a browser, or serve this directory with a local web server. The offline pages use local stylesheets, fonts and images. The desktop browser renders were visually reviewed against online screenshots; desktop and phone tests blocked all external requests and found no missing images or local files. This is a verified visual reading copy, not a functioning Surly storefront.

## Preserved material

- Original downloaded page HTML, unchanged, at the top level.
- Browser-rendered HTML, full-page online and offline screenshots, and verification reports in `visual-capture/`.
- Original response bodies in `visual-capture/surly-pages.har`, with supplemental CSS dependencies in `extra-resources.json`. Cookie/authentication header metadata is removed; response bodies are preserved.
- 280 captured resources in `offline/assets/`, including 66 CSS responses, font files, images and scripts. `offline/resource-manifest.json` maps URLs to files and records original response-body hashes. CSS copies have their asset paths rewritten; original CSS remains in the HAR/supplemental archive.
- Source HTML retrieval records in `manifest.json`, and checksums covering the archive in `SHA256SUMS`.
- Manufacturer frame-sheet PDFs linked from both pages.

## Visual-copy changes and limitations

Specifications were expanded and the live pages scrolled through before capture to reveal animated sections. The offline copies use the captured high-resolution images at all viewport sizes. Script files are saved, but execution and inline event handlers are disabled in these visual reading copies. Search, shopping, account, carousels and other server-dependent functions are not reproduced. Standard disclosure sections remain usable. Navigation links still lead to Surly; frame-sheet links open saved PDFs.

The online capture could not obtain certain advertising/analytics scripts and a Shop Pay endpoint (listed in the resource manifest). These did not prevent the verified pages from rendering. No missing CSS dependencies remain. Live announcement content/animation can differ from the frozen copy; the archive is not claimed to be a pixel-identical interactive clone.

These are current captures of Surly’s legacy references, not historical Wayback captures. They do not establish geometry for every production year. Surly’s 2016 geometry retains its preliminary/subject-to-change qualification.

## Website addition

`site-additions/docs/frame/geometry.md` presents the two geometry tables with source links and qualifications. `site-additions/docs/archive/pugsley-geometry/` contains the publication bundle. These are prepared additions; the actual site repository is not available here, so integration and publication remain outstanding. Historical catalog/Wayback gap-filling remains separate work.
