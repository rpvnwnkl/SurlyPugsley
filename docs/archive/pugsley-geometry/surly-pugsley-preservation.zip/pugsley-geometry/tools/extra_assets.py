from pathlib import Path
from urllib.request import Request,urlopen
import json,base64,concurrent.futures
root=Path(__file__).resolve().parent.parent
urls=json.loads((root/'offline/resource-manifest.json').read_text())['missing_css_dependencies']
urls=[u for u in urls if '#Shape-Arch' not in u]
def fetch(u):
 try:
  with urlopen(Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=25) as r:
   b=r.read();return {'request':{'method':'GET','url':u},'response':{'status':r.status,'content':{'mimeType':r.headers.get_content_type(),'encoding':'base64','text':base64.b64encode(b).decode()}}}
 except Exception as e:print('FAILED',u,str(e));return None
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:entries=[e for e in ex.map(fetch,urls) if e]
(root/'visual-capture/extra-resources.json').write_text(json.dumps(entries))
print(len(entries),'additional assets saved')
