const {chromium}=require('/Users/mattmills/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),path=require('path'),http=require('http');
const root=path.resolve(__dirname,'..');
(async()=>{
 const server=http.createServer((req,res)=>{
  const f=path.join(root,'../..',decodeURIComponent(req.url.split('?')[0]));
  const types={'.css':'text/css','.js':'text/javascript','.html':'text/html','.png':'image/png','.jpg':'image/jpeg','.woff2':'font/woff2','.svg':'image/svg+xml'};
  try{res.setHeader('Content-Type',types[path.extname(f)]||'application/octet-stream');res.end(fs.readFileSync(f))}catch{res.statusCode=404;res.end()}
 });await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
 const browser=await chromium.launch({executablePath:'/Applications/Chromium.app/Contents/MacOS/Chromium',headless:true});
 const results=[];
 for(const width of [1440,390])for(const slug of ['2016','gen2']){
  const ctx=await browser.newContext({viewport:{width,height:1000},deviceScaleFactor:1,serviceWorkers:'block'});const blocked=[];const failed=[];
  await ctx.route('**/*',r=>{if(r.request().url().startsWith(`http://127.0.0.1:${port}/`))r.continue();else{blocked.push(r.request().url());r.abort()}});
  const page=await ctx.newPage();page.on('response',r=>{if(r.status()>=400)failed.push({url:r.url(),status:r.status()})});
  await page.goto(`http://127.0.0.1:${port}/research-archive/pugsley-geometry/offline/${slug}.html`,{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);
  await page.screenshot({path:path.join(root,'visual-capture',`${slug}-offline-${width}.png`),fullPage:true});
  const state=await page.evaluate(()=>({tables:[...document.querySelectorAll('table')].filter(t=>t.textContent.includes('Reach')&&t.textContent.includes('Stack')).map(t=>t.innerText),missingImages:[...document.images].filter(i=>!i.complete||i.naturalWidth===0).map(i=>i.currentSrc),font:getComputedStyle(document.body).fontFamily,height:document.documentElement.scrollHeight}));
  results.push({slug,width,...state,blocked,failed});console.log(slug,width,'missing images',state.missingImages.length,'external requests blocked',blocked.length,'404s',failed.length);await ctx.close();
 }
 for(const width of [1440,390]){
 const page=await browser.newPage({viewport:{width,height:1000}});
 await page.goto(`http://127.0.0.1:${port}/site-additions/preview/frame/geometry.html`);
 await page.screenshot({path:path.join(root,'visual-capture',`geometry-preview-${width}.png`),fullPage:true});
 const check=await page.evaluate(()=>({tableCount:document.querySelectorAll('table').length,documentWidth:document.documentElement.scrollWidth,viewport:innerWidth}));
 if(check.tableCount!==2||check.documentWidth>width)throw Error('Preview layout validation failed');
 console.log('Geometry preview',width,JSON.stringify(check));await page.close();
 }
 await browser.close();server.close();fs.writeFileSync(path.join(root,'visual-capture','offline-verification.json'),JSON.stringify(results,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
