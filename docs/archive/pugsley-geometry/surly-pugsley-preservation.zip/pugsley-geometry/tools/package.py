from pathlib import Path
import json,hashlib,shutil,zipfile,datetime
r=Path(__file__).resolve().parent.parent
site=r.parents[1]/'site-additions'; dest=site/'docs/archive/pugsley-geometry'
# Remove anonymous browser cookie metadata from the distributable HAR. Resource bodies stay intact.
p=r/'visual-capture/surly-pages.har';har=json.loads(p.read_text())
for e in har['log']['entries']:
 for side in ['request','response']:
  e[side]['cookies']=[]
  e[side]['headers']=[h for h in e[side]['headers'] if h['name'].lower() not in ['cookie','set-cookie','authorization']]
p.write_text(json.dumps(har))
for slug in ['2016','gen2']:
 shutil.copy2(r/f'{slug}-frame-sheet.pdf',r/'offline'/f'{slug}-frame-sheet.pdf')
 f=r/'offline'/f'{slug}.html';s=f.read_text()
 import re
 s=re.sub(r'href="https://surlybikes.com/cdn/shop/files/[^" ]+\.pdf[^" ]*"',f'href="{slug}-frame-sheet.pdf"',s)
 f.write_text(s)
 shutil.copy2(r/f'{slug}-frame-sheet.pdf',dest/f'{slug}-frame-sheet.pdf')
readme='''# Preserved Surly Pugsley references

Captured September 26, 2026 UTC (September 25 in New York).

## Open the archive

- [2016 legacy Pugsley: styled offline page](offline/2016.html)
- [Pugsley Gen. 2: styled offline page](offline/gen2.html)
- [2016 frame sheet](2016-frame-sheet.pdf)
- [Gen. 2 frame sheet](gen2-frame-sheet.pdf)

Open `offline/index.html` in a browser, or serve this directory with a local web server. The offline pages use local stylesheets, fonts and images. The desktop browser renders were visually reviewed against online screenshots; desktop and phone tests blocked all external requests and found no missing images or local files. This is a verified visual reading copy, not a functioning Surly storefront.

## Preserved material

- Original downloaded page HTML, unchanged, at the top level.
- Browser-rendered HTML, full-page online and offline screenshots, and verification reports in `visual-capture/`.
- Original response bodies in `visual-capture/surly-pages.har`, with supplemental CSS dependencies in `extra-resources.json`. Cookie/authentication header metadata is removed; response bodies are preserved.
- 280 captured resources in `offline/assets/`, including 66 CSS responses, font files, images and scripts. `offline/resource-manifest.json` maps URLs to files and records original response-body hashes. CSS copies have their asset paths rewritten; original CSS remains in the HAR/supplemental archive.
- Source HTML retrieval records in `manifest.json`, and checksums covering the archive in `SHA256SUMS`.
- Manufacturer frame-sheet PDFs linked from both pages.

## Visual-copy changes and limitations

Specifications were expanded and the live pages scrolled through before capture to reveal animated sections. The offline copies use the captured high-resolution images at all viewport sizes. Script files are saved, but execution and inline event handlers are disabled in these visual reading copies. Search, shopping, account, carousels and other server-dependent functions are not reproduced. Standard disclosure sections remain usable. Navigation links still lead to Surly; frame-sheet links open saved PDFs.

The online capture could not obtain certain advertising/analytics scripts and a Shop Pay endpoint (listed in the resource manifest). These did not prevent the verified pages from rendering. No missing CSS dependencies remain. Live announcement content/animation can differ from the frozen copy; the archive is not claimed to be a pixel-identical interactive clone.

These are current captures of Surly’s legacy references, not historical Wayback captures. They do not establish geometry for every production year. Surly’s 2016 geometry retains its preliminary/subject-to-change qualification.

## Website addition

`site-additions/docs/frame/geometry.md` presents the two geometry tables with source links and qualifications. `site-additions/docs/archive/pugsley-geometry/` contains the publication bundle. These are prepared additions; the actual site repository is not available here, so integration and publication remain outstanding. Historical catalog/Wayback gap-filling remains separate work.
'''
(r/'README.md').write_text(readme)
meta=[]
for slug,url in [('2016','https://surlybikes.com/cdn/shop/files/Surly_Pugsley_Frame_Sheet_972af7f5-192a-4503-830a-2457a0d5d048.pdf?v=15884292519824483206'),('gen2','https://surlybikes.com/cdn/shop/files/21995_SUR_Pugsley_Framesheet_INST_VF.pdf?v=3199353969629195133')]:
 f=r/f'{slug}-frame-sheet.pdf';assert f.read_bytes().startswith(b'%PDF')
 meta.append({'file':f.name,'url':url,'retrieved_date_utc':'2026-09-26','sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(r/'frame-sheet-manifest.json').write_text(json.dumps(meta,indent=2))
files=[f for f in sorted(r.rglob('*')) if f.is_file() and f.name!='SHA256SUMS' and '__pycache__' not in f.parts]
(r/'SHA256SUMS').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(r))+'\n' for f in files))
shutil.copytree(r/'offline',dest/'offline',dirs_exist_ok=True)
with zipfile.ZipFile(dest/'surly-pugsley-preservation.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files+[r/'SHA256SUMS']:z.write(f,Path('pugsley-geometry')/f.relative_to(r))
index=dest/'index.md';s=index.read_text().split('\n## Manufacturer frame sheets')[0];s+='\n## Manufacturer frame sheets\n\n- [2016 legacy frame sheet](2016-frame-sheet.pdf)\n- [Gen. 2 frame sheet](gen2-frame-sheet.pdf)\n';index.write_text(s)
(site/'README.md').write_text('''# Prepared website additions

Status: prepared and checked locally; not integrated into the website repository and not published.

Merge `docs/` into the existing MkDocs `docs/` directory. The new `frame/geometry.md` is intended to replace the old placeholder geometry page after reviewing the target repository. Preserve unrelated site changes.

Suggested MkDocs navigation entries:

```yaml
- Frame geometry: frame/geometry.md
- Sources & archive:
    - Surly catalogs & crank documents: archive/surly-documents/index.md
    - Preserved Pugsley pages: archive/pugsley-geometry/index.md
```

Link both archive entries from the existing archive overview. The standalone HTML files under `offline/` should be copied as static files, not processed as Markdown. The ZIP provides the full archival package including original responses and screenshots. Preserve all assets and relative paths.

Existing catalog PDFs remain unchanged. Geometry table values were extracted directly from the saved source HTML, keeping size labels and qualifications. Offline copies were checked with external networking blocked at 1440px and 390px widths. A standalone preview is available at `preview/frame/geometry.html`; it illustrates content and links, not the existing site's final theme.

Before publication: obtain repository access, reconcile its current navigation/content, run its MkDocs build, and check the deployed download paths. No live-site build can be claimed from this integration bundle alone.
''')
print('Packaged',round((dest/'surly-pugsley-preservation.zip').stat().st_size/1e6,1),'MB')
