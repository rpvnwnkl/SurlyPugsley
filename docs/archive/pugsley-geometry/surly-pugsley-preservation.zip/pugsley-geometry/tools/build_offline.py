from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urljoin,urlsplit
import json,base64,hashlib,re,html,os,shutil
root=Path(__file__).resolve().parent.parent
cap=root/'visual-capture'; out=root/'offline'; assets=out/'assets';assets.mkdir(parents=True,exist_ok=True)
har=json.loads((cap/'surly-pages.har').read_text())
resources={}; failures=[]
extra=cap/'extra-resources.json'
if extra.exists():har['log']['entries']+=json.loads(extra.read_text())
for e in har['log']['entries']:
 u=e['request']['url'];r=e['response'];c=r['content']
 if e['request']['method']!='GET':continue
 if not (200<=r['status']<300) or 'text' not in c:
  failures.append({'url':u,'status':r['status']});continue
 b=base64.b64decode(c['text']) if c.get('encoding')=='base64' else c['text'].encode()
 ext=Path(urlsplit(u).path).suffix
 if not re.fullmatch(r'\.[a-zA-Z0-9]{1,8}',ext):
  ext={ 'text/css':'.css','application/javascript':'.js','text/javascript':'.js','text/html':'.html'}.get(c.get('mimeType','').split(';')[0],'.bin')
 name=hashlib.sha256(u.encode()).hexdigest()[:20]+ext
 resources[u]={'file':'assets/'+name,'mime':c.get('mimeType'),'sha256_original':hashlib.sha256(b).hexdigest(),'bytes':len(b),'body':b}
def local(u,base,prefix=''):
 if u.startswith('#'):return u
 full=urljoin(base,html.unescape(u))
 v=resources.get(full)
 return prefix+v['file'] if v else u
missing=set()
def css(s,base,prefix):
 def sub(m):
  raw=m.group(1).strip().strip('\"\'');full=urljoin(base,raw)
  if raw.startswith('#'):return m.group(0)
  if full.startswith(('http:','https:')) and full not in resources:missing.add(full)
  return 'url("'+local(raw,base,prefix)+'")'
 s=re.sub(r'url\(([^)]+)\)',sub,s)
 return re.sub(r'(@import\s+)[\"\']([^\"\']+)[\"\']',lambda m:m[1]+'"'+local(m[2],base,prefix)+'"',s)
for u,r in resources.items():
 b=r['body']
 if r['mime'].startswith('text/css'):b=css(b.decode('utf-8','replace'),u,'../').encode()
 (out/r['file']).write_bytes(b)
class Mirror(HTMLParser):
 def __init__(self,base,images):super().__init__(convert_charrefs=False);self.base=base;self.parts=[];self.style=False;self.images=iter(images)
 def handle_starttag(self,t,attrs):
  if t=='base':return
  a=dict(attrs)
  if t=='img':
   current=next(self.images,{}).get('url')
   if current:a['src']=current
   a.pop('srcset',None)
  if t=='source':a.pop('srcset',None)
  if t=='script':a['type']='application/x-preserved-script'
  if t=='meta' and a.get('http-equiv','').lower()=='content-security-policy':return
  for k in list(a):
   v=a[k]
   if v is None:continue
   if k in ['src','poster'] or (k=='href' and t=='link'):a[k]=local(v,self.base)
   elif k=='srcset':a[k]=', '.join(local(p.strip().split()[0],self.base)+' '+ ' '.join(p.strip().split()[1:]) for p in v.split(',') if p.strip())
   elif k=='style':a[k]=css(v,self.base,'')
   elif k=='href' and t=='a' and not v.startswith('#'):a[k]=urljoin(self.base,v)
   elif k.startswith('on'):del a[k]
  if t=='style':self.style=True
  self.parts.append('<'+t+''.join(' '+k+('="'+html.escape(v,quote=True)+'"' if v is not None else '') for k,v in a.items())+'>')
 def handle_startendtag(self,t,a):self.handle_starttag(t,a)
 def handle_endtag(self,t):
  self.parts.append('</'+t+'>')
  if t=='style':self.style=False
 def handle_data(self,d):self.parts.append(css(d,self.base,'') if self.style else d)
 def handle_entityref(self,n):self.parts.append('&'+n+';')
 def handle_charref(self,n):self.parts.append('&#'+n+';')
 def handle_comment(self,d):self.parts.append('<!--'+d+'-->')
 def handle_decl(self,d):self.parts.append('<!'+d+'>')
for slug,url in [('2016','https://surlybikes.com/products/pugsley_2016'),('gen2','https://surlybikes.com/products/pugsley')]:
 images=next(x['images'] for x in json.loads((cap/'capture-report.json').read_text()) if x['slug']==slug)
 p=Mirror(url,images);p.feed((cap/f'{slug}-rendered.html').read_text());(out/f'{slug}.html').write_text(''.join(p.parts))
manifest={'resources':[{ 'url':u,**{k:v for k,v in r.items() if k!='body'}} for u,r in resources.items()],'failed_responses':failures,'missing_css_dependencies':sorted(missing)}
(out/'resource-manifest.json').write_text(json.dumps(manifest,indent=2))
(out/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Preserved Surly Pugsley pages</title><h1>Preserved Surly Pugsley pages</h1><p>Local visual reading copies. Saved September 26, 2026 UTC. Scripts preserved as files but disabled here; shop functions require Surly servers.</p><ul><li><a href="2016.html">2016 legacy Pugsley</a></li><li><a href="gen2.html">Pugsley Gen. 2</a></li></ul>')
print(len(resources),'resources saved;',len(missing),'missing CSS dependencies;',len(failures),'failed responses')
