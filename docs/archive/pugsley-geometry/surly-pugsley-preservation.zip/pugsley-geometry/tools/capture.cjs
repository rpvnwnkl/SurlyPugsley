const {chromium}=require('/Users/mattmills/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Chromium.app/Contents/MacOS/Chromium',headless:true});
 const dir=path.join(root,'visual-capture');fs.mkdirSync(dir,{recursive:true});
 const context=await browser.newContext({viewport:{width:1440,height:1000},deviceScaleFactor:1,serviceWorkers:'block',recordHar:{path:path.join(dir,'surly-pages.har'),content:'embed',mode:'full'}});
 // This is a fresh anonymous context. Do not submit forms or analytics POSTs.
 await context.route('**/*',route=>route.request().method()==='GET'?route.continue():route.abort());
 const report=[];
 for(const [slug,url] of [['2016','https://surlybikes.com/products/pugsley_2016'],['gen2','https://surlybikes.com/products/pugsley']]){
  const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(url,{waitUntil:'networkidle',timeout:60000});
  await page.evaluate(async()=>{document.querySelectorAll('details').forEach(x=>x.open=true);document.querySelectorAll('img').forEach(x=>x.loading='eager');await document.fonts.ready;});
  await page.waitForTimeout(2500);
  // Reveal sections that the live theme animates only after scrolling.
  const height=await page.evaluate(()=>document.documentElement.scrollHeight);
  for(let y=0;y<height;y+=700){await page.evaluate(y=>window.scrollTo(0,y),y);await page.waitForTimeout(180)}
  await page.waitForTimeout(1200);await page.evaluate(()=>window.scrollTo(0,0));await page.waitForTimeout(800);
  fs.writeFileSync(path.join(dir,slug+'-rendered.html'),await page.content());
  await page.screenshot({path:path.join(dir,slug+'-online.png'),fullPage:true});
  const info=await page.evaluate(()=>({title:document.title,tables:[...document.querySelectorAll('table')].filter(t=>t.textContent.includes('Reach')&&t.textContent.includes('Stack')).map(t=>t.outerHTML),images:[...document.images].map(i=>({url:i.currentSrc,loaded:i.complete&&i.naturalWidth>0})),fonts:document.fonts.status,height:document.documentElement.scrollHeight}));
  report.push({slug,url,capturedUTC:new Date().toISOString(),...info,errors});console.log(slug,info.tables.length,'geometry tables',info.images.filter(x=>!x.loaded).length,'missing images');
  await page.close();
 }
 await context.close();await browser.close();fs.writeFileSync(path.join(dir,'capture-report.json'),JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
