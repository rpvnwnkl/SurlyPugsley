from pathlib import Path
from html.parser import HTMLParser
import re,shutil,json
root=Path(__file__).resolve().parent.parent
site=root.parents[1]/'site-additions/docs'
class Table(HTMLParser):
 def __init__(self):super().__init__();self.depth=0;self.tables=[];self.rows=[];self.row=[];self.cell=None
 def handle_starttag(self,t,a):
  if t=='table':self.depth+=1;self.rows=[]
  if self.depth and t=='tr':self.row=[]
  if self.depth and t in ['td','th']:self.cell=[]
 def handle_data(self,d):
  if self.cell is not None:self.cell.append(d)
 def handle_endtag(self,t):
  if t in ['td','th'] and self.cell is not None:self.row.append(' '.join(''.join(self.cell).split()));self.cell=None
  if t=='tr' and self.depth and self.row:self.rows.append(self.row)
  if t=='table' and self.depth:self.depth-=1;self.tables.append(self.rows)
def table(slug):
 p=Table();p.feed((root/f'surly-pugsley-{slug}-source.html').read_text())
 rows=next(t for t in p.tables if any(r and r[0]=='Reach' for r in t))
 assert len(set(map(len,rows)))==1
 return '\n'.join('| '+' | '.join(r)+' |' for r in [rows[0],['---']*len(rows[0])]+rows[1:])
geo=site/'frame';geo.mkdir(parents=True,exist_ok=True)
archive=site/'archive/pugsley-geometry';archive.mkdir(parents=True,exist_ok=True)
shutil.copy2(root/'geometry-diagram.png',archive/'geometry-diagram.png')
body='''# Frame geometry

Two manufacturer references for comparing Pugsley frame sizes: Surly’s 2016 legacy page and its Gen. 2 page. These are separate references; neither establishes the geometry of every earlier Pugsley.

Measurements below are transcribed from Surly’s tables without recalculation. Linear measurements are in millimetres; angles are in degrees. Original size labels are retained.

![Surly frame geometry diagram](../archive/pugsley-geometry/geometry-diagram.png)

## Pugsley — 2016 legacy reference

[Surly page](https://surlybikes.com/products/pugsley_2016) · [Preserved page](../archive/pugsley-geometry/offline/2016.html)

'''+table('2016')+'''

Surly’s qualification: “All dimensions are preliminary and subject to change.” Standover is measured at the centre of the top tube with an approximately 740 mm diameter tire.

## Pugsley Gen. 2

[Surly page](https://surlybikes.com/products/pugsley) · [Preserved page](../archive/pugsley-geometry/offline/gen2.html)

'''+table('gen2')+'''

## Earlier bikes and dated catalogs

Use the [catalog collection](../archive/surly-documents/index.md) to check a specific earlier model year. Differences in a table may reflect frame changes, measurement conventions, or revised documentation; do not assume that one table applies to a whole range of years.

## About these sources

Both web pages were captured on September 26, 2026 UTC (September 25 in New York). “2016” identifies Surly’s legacy reference, not the capture date. The Gen. 2 page does not establish a complete year-by-year production history.

[Preservation details and downloads](../archive/pugsley-geometry/index.md). This site is independent of Surly.
'''
(geo/'geometry.md').write_text(body)
(archive/'index.md').write_text('''# Preserved Surly Pugsley pages

Manufacturer reference pages saved September 26, 2026 UTC (September 25 in New York), with local stylesheets, fonts, images and captured scripts.

| Reference | Preserved page | Original |
| --- | --- | --- |
| Pugsley — 2016 legacy page | [Open preserved page](offline/2016.html) | [Surly](https://surlybikes.com/products/pugsley_2016) |
| Pugsley Gen. 2 | [Open preserved page](offline/gen2.html) | [Surly](https://surlybikes.com/products/pugsley) |

For quick size comparisons, use the [frame geometry tables](../../frame/geometry.md).

[Download the preservation bundle](surly-pugsley-preservation.zip). It includes the original source HTML, styled reading copies and assets, reference screenshots, provenance and verification records.

The preserved pages retain Surly’s appearance, with specifications expanded for reading. They are local visual copies, not operating storefronts: scripts are preserved as files but disabled in the reading copies, and checkout, search and account services do not work offline. External navigation links lead to the original website.

These are present-day captures of Surly’s legacy references. They are not dated Internet Archive snapshots and do not prove that every earlier model year had the same specifications.
''')
print('Prepared',geo/'geometry.md')
