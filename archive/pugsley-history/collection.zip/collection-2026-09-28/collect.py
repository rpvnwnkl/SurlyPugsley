"""Bounded archival collection. Preserve bytes, headers, dates, and failed attempts."""
from pathlib import Path
import concurrent.futures, datetime, hashlib, json, re, shutil, subprocess
from urllib.parse import urlencode, urlsplit

ROOT = Path(__file__).resolve().parent
EXISTING = Path('/Users/mattmills/Documents/pugsleywiki/SurlyPugsley/docs/archive/pugsley-frame-2010')
RECOVERY = Path('/private/tmp/pugsley-2010-recovery')

def fetch(url, directory, label):
    directory.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha256(url.encode()).hexdigest()[:20]
    body, headers = directory / (key+'.body'), directory / (key+'.headers')
    proc = subprocess.run(['curl','-L','--max-time','22','--connect-timeout','8','-sS',
        '-D',str(headers),'-o',str(body),'-w','%{json}',url],capture_output=True,text=True)
    try: info=json.loads(proc.stdout)
    except ValueError: info={}
    data=body.read_bytes() if body.exists() else b''
    row=dict(label=label,requested_url=url,resolved_url=info.get('url_effective'),
        http_status=info.get('http_code',0),content_type=info.get('content_type'),
        bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),
        body=str(body.relative_to(ROOT)),headers=str(headers.relative_to(ROOT)),
        error=proc.stderr.strip(),retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (directory/(key+'.json')).write_text(json.dumps(row,indent=2)+'\n')
    return row

def recover_asset(row):
    path=row['path']
    if row['http_status']==200 and row['bytes']:
        return dict(row, recovery_status='downloaded-first-pass')
    # The original collection already holds these exact assets; retain its provenance.
    original=json.loads((EXISTING/'manifest.json').read_text())
    held=next((x for x in original['assets'] if x['original_url']==row['original_url'] and x['available']),None)
    if held:
        return dict(row,recovery_status='already-held',existing_local_path=held['local_path'])
    lookup=fetch('https://archive.org/wayback/available?'+urlencode({'url':row['original_url'],'timestamp':'20100421'}),ROOT/'availability',path)
    try: closest=json.loads((ROOT/lookup['body']).read_text())['archived_snapshots']['closest']
    except (ValueError,KeyError,FileNotFoundError):
        return dict(row,recovery_status='availability-unresolved',availability=lookup)
    ts=closest['timestamp']
    result=fetch('https://web.archive.org/web/'+ts+'id_/'+row['original_url'],ROOT/'recovered',path)
    result.update(original_url=row['original_url'],path=path,requested_capture='20100421123801',available_capture=ts,availability=lookup)
    result['recovery_status']='downloaded' if result['http_status']==200 and result['bytes'] else 'download-failed'
    print('ASSET',path,result['recovery_status'],flush=True)
    return result

def page_task(task):
    label,url=task
    row=fetch(url,ROOT/'pages',label)
    print('PAGE',label,row['http_status'],row['bytes'],flush=True)
    return row

def main():
    ROOT.mkdir(parents=True,exist_ok=True)
    shutil.copytree(RECOVERY,ROOT/'first-pass',dirs_exist_ok=True)
    first=json.loads((RECOVERY/'recovery.json').read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        assets=list(pool.map(recover_asset,first))
    (ROOT/'asset-recovery.json').write_text(json.dumps(assets,indent=2)+'\n')
    manifest=json.loads((EXISTING/'manifest.json').read_text())
    captures=[x for x in manifest['captures'] if x.get('statuscode')=='200' and x.get('mimetype')=='text/html']
    (ROOT/'known-frame-captures.json').write_text(json.dumps(captures,indent=2)+'\n')
    # Representative dated captures are not assertions about model years.
    by_year={}
    for x in sorted(captures,key=lambda x:x['timestamp']): by_year.setdefault(x['timestamp'][:4],x)
    tasks=[('Original frame page, capture '+x['timestamp'], 'https://web.archive.org/web/'+x['timestamp']+'id_/'+x['original']) for x in by_year.values()]
    tasks += [('Surly Pugsley design explanation','https://surlybikes.com/pages/pugsley'),
        ('Surly hub, fork and disc compatibility','https://surlybikes.com/pages/hub-fork-and-disc-brake-compatibility')]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: pages=list(pool.map(page_task,tasks))
    (ROOT/'page-downloads.json').write_text(json.dumps(pages,indent=2)+'\n')
    # These URLs are discovery leads from existing references; a successful index
    # response must still be inspected before assigning any product/version label.
    candidates=[('Pugsley page URL discovery','surlybikes.com/*pugsley*'),
        ('Neck Romancer page discovery','surlybikes.com/bikes/neck_romancer_pug*'),
        ('Pug Ops legacy page discovery','surlybikes.com/bikes/legacy/pug_ops*')]
    indexes=[]
    for label,url in candidates:
        query=urlencode({'url':url,'output':'json','filter':['statuscode:200','mimetype:text/html'],'collapse':'urlkey','fl':'timestamp,original,mimetype,statuscode,digest','limit':'3000'},doseq=True)
        indexes.append(fetch('https://web.archive.org/cdx/search/cdx?'+query,ROOT/'indexes',label))
    (ROOT/'index-downloads.json').write_text(json.dumps(indexes,indent=2)+'\n')
    print('Collection finished',len(assets),'assets examined;',len(pages),'page requests;',len(indexes),'index requests.',flush=True)

if __name__=='__main__': main()
