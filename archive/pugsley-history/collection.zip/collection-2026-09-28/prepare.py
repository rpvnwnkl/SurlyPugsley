"""Create separately labeled local reading copies; never edit captured originals."""
from pathlib import Path
from urllib.parse import urljoin,urlsplit,urlencode
import hashlib, html, json, re, shutil
from bs4 import BeautifulSoup, Comment
from collect import ROOT, EXISTING, fetch

OUT=ROOT/'prepared'
OUT.mkdir(exist_ok=True)
records=json.loads((ROOT/'asset-recovery.json').read_text())

def strip_active(soup):
    for x in soup(['script','iframe','object','embed','base']): x.decompose()
    for x in soup.find_all(string=lambda t:isinstance(t,Comment)): x.extract()
    for x in soup.find_all(True):
        for attr in list(x.attrs):
            if attr.lower().startswith('on'): del x[attr]
        if x.get('href','').lower().startswith('javascript:'):
            target={'metric':'#geo-metric','inches':'#geo-english'}.get(x.get('id'))
            if target: x['href']=target
            elif x['href'].startswith('javascript:#'): x['href']=x['href'][11:]
            else: del x['href']
    for x in soup.select('form'): x.name='div'; x.attrs={}
    for x in soup.select('input,button,select,textarea'):
        x['disabled']='disabled'
        x.attrs.pop('src',None)

def build_2010():
    out=OUT/'pugsley-frame-2010'
    shutil.copytree(EXISTING,out,dirs_exist_ok=True)
    # This old ZIP remains the original collection; newly built bundle is separate.
    recovered=out/'recovered-assets'; recovered.mkdir(exist_ok=True)
    mapping={}; provenance=[]; missing=[]
    for row in records:
        status=row['recovery_status']; path=row['path']
        if status=='already-held':
            mapping[path]=row['existing_local_path']; continue
        if status not in ('downloaded','downloaded-first-pass'):
            missing.append(path); continue
        source=ROOT/('first-pass/'+row['body'] if status=='downloaded-first-pass' else row['body'])
        data=source.read_bytes()
        # Reject error responses disguised as successful image downloads.
        if path.lower().endswith(('.png','.jpg','.gif')) and not data.startswith((b'\x89PNG',b'\xff\xd8',b'GIF8')):
            missing.append(path); continue
        rel=Path('recovered-assets')/urlsplit(path).path.lstrip('/')
        (out/rel).parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,out/rel)
        mapping[path]=rel.as_posix()
        provenance.append(dict(path=path,local_path=rel.as_posix(),sha256=hashlib.sha256(data).hexdigest(),
            available_capture=row.get('available_capture',row.get('capture_timestamp')),response_record=row))
    # Preserve the source stylesheet and create a separate rewritten stylesheet.
    raw=(out/'assets/css/base.css').read_text()
    def cssurl(match):
        value=match.group(1).strip('"\' ')
        return "url('../../"+mapping[value]+"')" if value in mapping else 'none'
    rewritten=re.sub(r'url\(([^)]+)\)',cssurl,raw)
    rewritten+='\n/* Reading-copy additions: scripts disabled, all source detail panels visible. */\n#geometry,#highlights,#related-items,#specs,#geo-metric,#geo-english{display:block!important;}\n'
    (out/'assets/css/reading.css').write_text(rewritten)
    soup=BeautifulSoup((out/'source.html').read_text(),'html.parser')
    strip_active(soup)
    for a in soup.select('a[title="Curry Squirt"]'):
        a['href']='/uploads/frames/FM3171.jpg'
    for link in soup.select('link[rel="stylesheet"]'):
        if '/css/base.css' in link.get('href',''): link['href']='assets/css/reading.css'
        else: link.decompose()
    for tag in soup.find_all(True):
        for attr in ('src','href'):
            value=tag.get(attr)
            if not value: continue
            if value in mapping: tag[attr]=mapping[value]
            elif value.startswith('javascript:#'): tag[attr]=value.removeprefix('javascript:')
            elif value.startswith('/') or value.startswith('http://surlybikes.com'):
                tag[attr]='https://web.archive.org/web/20100421123801/'+urljoin('http://surlybikes.com',value)
        if tag.has_attr('style'):
            tag['style']=re.sub(r'url\(([^)]+)\)',lambda m: "url('"+mapping[m.group(1).strip('"\' ')] +"')" if m.group(1).strip('"\' ') in mapping else 'none',tag['style'])
    (out/'offline.html').write_text(str(soup))
    (out/'SHA256SUMS').rename(out/'original-SHA256SUMS')
    (out/'restoration-record.json').write_text(json.dumps(dict(
        status='Restored reading copy; includes nearest available asset captures from different dates.',
        original_source_unchanged=True,original_stylesheet_unchanged=True,
        modifications=['Local asset paths rewritten in derived reading.css and offline.html',
            'Scripts, Flash, forms and event handlers disabled; all detail panels shown',
            'Uncollected navigation/image destinations link to Internet Archive',
            'Unused/unavailable CSS image references suppressed in derived stylesheet'],
        recovered_assets=provenance,unresolved_paths=missing),indent=2)+'\n')
    return dict(path='pugsley-frame-2010/offline.html',recovered=len(provenance),missing=missing)

def collect_variant(label,original,timestamp):
    lookup=fetch('https://archive.org/wayback/available?'+urlencode({'url':original,'timestamp':timestamp}),ROOT/'availability',label)
    try: closest=json.loads((ROOT/lookup['body']).read_text())['archived_snapshots']['closest']
    except (ValueError,KeyError,FileNotFoundError): return dict(label=label,original_url=original,status='availability-unresolved',availability=lookup)
    ts=closest['timestamp']
    row=fetch('https://web.archive.org/web/'+ts+'id_/'+original,ROOT/'pages',label)
    row.update(original_url=original,available_capture=ts,availability=lookup)
    return row

def reading_copy(row,index):
    source=ROOT/row['body']
    soup=BeautifulSoup(source.read_bytes(),'html.parser')
    title=soup.title.get_text(' ',strip=True) if soup.title else row['label']
    if 'could not be found' in title.lower() or 'wayback machine' in title.lower():
        return dict(row,status='not-a-product-page',title=title)
    if 'surly' not in soup.get_text().lower() or 'pug' not in soup.get_text().lower():
        return dict(row,status='unverified-response',title=title)
    directory=OUT/('reference-'+str(index)); directory.mkdir(exist_ok=True)
    shutil.copy2(source,directory/'source.html')
    main=soup.find('main') or soup.find(id='main-content') or soup.body
    strip_active(main)
    for el in main('link'): el.unwrap()
    for el in main('style'): el.decompose()
    unresolved=[]; assets=[]
    original=row.get('original_url') or row['requested_url']
    if 'web.archive.org/web/' in original:
        original=re.sub(r'^https?://web.archive.org/web/[^/]+/','',original)
    archived='web.archive.org' in row['requested_url']
    for n,img in enumerate(main.select('img')):
        value=img.get('src')
        if not value: continue
        url=urljoin(original,value)
        if archived:
            ts=row.get('available_capture') or re.search(r'/web/(\d+)',row['requested_url']).group(1)
            url='https://web.archive.org/web/'+ts+'id_/'+url
        asset=fetch(url,ROOT/'reading-assets',title+' image')
        if asset['http_status']==200 and (ROOT/asset['body']).read_bytes().startswith((b'\xff\xd8',b'\x89PNG',b'GIF8',b'RIFF')):
            dest='image-'+str(n)+'.'+({'image/png':'png','image/gif':'gif','image/webp':'webp'}.get((asset.get('content_type') or '').split(';')[0],'jpg'))
            shutil.copy2(ROOT/asset['body'],directory/dest); img['src']=dest; assets.append(asset)
        else:
            unresolved.append(url)
            placeholder=soup.new_tag('a',href=url)
            placeholder.string='[Image unavailable in this copy: '+(img.get('alt') or value)+']'
            img.replace_with(placeholder); continue
        for attr in ('srcset','sizes','loading','width','height'): img.attrs.pop(attr,None)
    for a in main.select('a[href]'):
        if not a['href'].startswith('#'): a['href']=urljoin(original,a['href'])
    # Source text is retained. Derived reading copies deliberately use simple styling.
    for tag in main.find_all(True):
        for attr in ('class','style','hidden'): tag.attrs.pop(attr,None)
    notice='Derived reading copy; original HTML is preserved separately. Original website styling and interactive services are not reproduced.'
    if unresolved: notice+=' Some embedded images could not be collected; see record.json.'
    document='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+html.escape(title)+'</title><style>body{font:18px/1.6 system-ui;margin:2rem auto;padding:0 1rem;max-width:75ch}img{max-width:100%;height:auto}table{display:block;overflow:auto}aside{padding:1rem;background:#eef2ed;font-size:.85rem}a{color:#245638}</style><aside>'+html.escape(notice)+' <a href="source.html">Source HTML</a> · <a href="'+html.escape(row['requested_url'])+'">Original or archived source</a> · <a href="../index.html">Collection</a></aside>'+str(main)+'</html>'
    (directory/'reading.html').write_text(document)
    record=dict(row,title=title,status='reading-copy-with-image-gaps' if unresolved else 'reading-copy',embedded_images=assets,unresolved_images=unresolved,reading_path=directory.name+'/reading.html')
    (directory/'record.json').write_text(json.dumps(record,indent=2)+'\n')
    print('READING',title,record['status'],flush=True)
    return record

def main():
    restoration=build_2010()
    pages=json.loads((ROOT/'page-downloads.json').read_text())
    variants=[collect_variant('Neck Romancer Pug product page','http://surlybikes.com/bikes/neck_romancer_pug','20120601'),
        collect_variant('Pug Ops legacy product page','https://surlybikes.com/bikes/legacy/pug_ops/pug_ops_grey/bike_specs','20180501')]
    (ROOT/'variant-downloads.json').write_text(json.dumps(variants,indent=2)+'\n')
    pages+=variants
    result=[]
    for index,row in enumerate(pages):
        if row.get('http_status')==200: result.append(reading_copy(row,index))
        else: result.append(dict(row,status='not-downloaded'))
    (ROOT/'prepared-manifest.json').write_text(json.dumps(dict(restoration=restoration,pages=result),indent=2)+'\n')
    links='<li><a href="pugsley-frame-2010/offline.html">Restored 2010 frame-page reading copy</a> — nearby capture dates, disabled scripts; full-size gallery images remain unresolved.</li>'
    for row in result:
        links+='<li>'+(('<a href="'+row['reading_path']+'">'+html.escape(row['label'])+'</a>') if row.get('reading_path') else html.escape(row['label']))+' — '+html.escape(row['status'])+'</li>'
    (OUT/'index.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pugsley archival collection — review</title><style>body{font:18px/1.6 system-ui;max-width:75ch;margin:3rem auto;padding:0 1rem}li{margin:1rem 0}a{color:#245638}</style><h1>Pugsley archival collection</h1><p>Local review collection. Dated captures are not model-year identifications. Reading copies are derivatives; raw source bytes and response records are preserved.</p><ul>'+links+'</ul></html>')
    print('PREPARED',restoration['recovered'],'recovered assets;',len(result),'page records',flush=True)

if __name__=='__main__': main()
