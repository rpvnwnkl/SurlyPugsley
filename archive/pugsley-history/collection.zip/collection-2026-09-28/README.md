# Pugsley archive collection — September 28, 2026

Open `prepared/index.html` to browse this local review collection. Nothing in this batch has been published to the website.

## Saved material

| Item | Result |
| --- | --- |
| Existing April 2010 frame page | Restored local reading copy with header, backgrounds, navigation artwork and instruction PDF. 35 recovered asset files are recorded, alongside previously held assets. |
| September 2009 frame-page capture | Source HTML and reading copy; one embedded image unresolved. |
| January 2010 frame-page capture | Source HTML and reading copy; embedded images collected. |
| February 2011 frame-page capture | Source HTML and reading copy; seven embedded images unresolved. |
| May 2012 Neck Romancer Pug capture | Source HTML and reading copy; six embedded images unresolved. |
| Surly Pugsley design explanation | Current official page saved, with a readable local copy. |
| Surly hub, fork and disc-brake compatibility | Current official page saved, with a readable local copy. |

Capture dates are not model-year identifications. These captures still need comparison before assigning them to model-year entries. The current technical articles describe historical equipment; collection does not establish that their advice applies to every Pugsley variant.

## Preservation and verification

Raw response bodies, response headers, requested and resolved URLs, retrieval times and SHA-256 hashes are retained. See `prepared-manifest.json`, `asset-recovery.json`, and each reading copy's `record.json`. Requests crossed midnight UTC; the folder uses the local date.

The restored 2010 page uses assets recovered from nearby captures, sometimes from different years. It is a reconstruction, not a claim that every asset came from the same snapshot. Its original HTML and original stylesheet were checked byte-for-byte against the existing collection and are unchanged. `original-SHA256SUMS` describes the earlier collection, including its earlier offline page; `COLLECTION-SHA256SUMS` covers the files in this new collection.

Reading copies disable scripts and forms. Both geometry-unit tables are made visible in the restored 2010 copy. Other newly collected pages use simple reading layouts. Unavailable images are identified with links. Original captured HTML is retained separately and may still contain original scripts and external references.

The restored 2010 page was visually inspected in a local browser. Derived reading pages and the rewritten stylesheet passed a local embedded-asset existence check. Source text was checked in all six additional reading copies.

## Unresolved work

- Four full-size 2010 gallery images remain uncollected; thumbnails are preserved.
- The Pug Ops legacy specification URL did not return an available snapshot in the lookup used. This does not establish that the page is absent from the archive.
- The January 2012 frame URL capture returned a Surly error page. Its raw response is retained as evidence but excluded from usable reading copies.
- Broader Wayback capture-index requests failed during this run. This is a useful collected batch, not a complete inventory of all Pugsley versions.
- Compare distinct content across the early captures, pursue Pug Ops and missing photographs, and integrate verified material into the site's existing archive in a later batch.

## Folder guide

- `prepared/`: browseable collection and derived reading copies.
- `pages/`, `recovered/`, `reading-assets/`, `first-pass/`: collected original response bodies and retrieval evidence.
- `availability/`, `indexes/`: archive lookups, including unsuccessful attempts.
- JSON manifests: machine-readable inventory, provenance, and gaps.
- `collect.py`, `prepare.py`: collection and preparation scripts; rerunning may make network requests.

Original Surly content retains its original attribution. Local collection does not grant republication rights.
